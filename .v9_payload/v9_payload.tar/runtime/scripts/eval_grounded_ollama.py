#!/usr/bin/env python3
"""Run frozen evidence-conditioned structural evals against a local Ollama model."""

from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import sys
import time
from typing import Any

import requests

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.grounded_eval import GroundedEvalError, score_response
from src.grounded_instruction import RESPONSE_POLICY
from src.retrieve_evidence import RetrievalError, load_verified_index

DEFAULT_CASES_PATH = Path("data/grounded/frozen_eval.jsonl")


def resolve_base_url() -> str:
    raw = os.getenv("OLLAMA_HOST", "http://127.0.0.1:11434")
    if raw.startswith(("http://", "https://")):
        return raw.rstrip("/")
    return f"http://{raw.rstrip('/')}"


def load_cases(path: Path) -> list[dict[str, Any]]:
    cases = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            case = json.loads(line)
        except json.JSONDecodeError as exc:
            raise GroundedEvalError(f"invalid JSON on line {line_number}: {exc.msg}") from exc
        if not isinstance(case, dict):
            raise GroundedEvalError(f"case line {line_number} must be an object")
        cases.append(case)
    if not cases:
        raise GroundedEvalError("at least one eval case is required")
    return cases


def validate_frozen_contract(
    dataset_manifest_path: Path,
    cases_path: Path,
    retrieval_index_path: Path | None = None,
    source_manifest_path: Path | None = None,
) -> dict[str, str]:
    """Bind evaluation to the exact artifacts recorded when the training data was prepared."""
    if not dataset_manifest_path.is_file():
        raise GroundedEvalError(f"dataset manifest not found: {dataset_manifest_path}")
    try:
        manifest = json.loads(dataset_manifest_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise GroundedEvalError(f"invalid dataset manifest: {exc.msg}") from exc
    if not isinstance(manifest, dict):
        raise GroundedEvalError("dataset manifest must be an object")

    artifacts: list[tuple[str, Path]] = [("frozen_eval_sha256", cases_path)]
    if retrieval_index_path is not None:
        artifacts.append(("retrieval_index_sha256", retrieval_index_path))
    if source_manifest_path is not None:
        artifacts.append(("source_manifest_sha256", source_manifest_path))
    for field, path in artifacts:
        if not path.is_file():
            raise GroundedEvalError(f"artifact not found for {field}: {path}")
        expected = _text(manifest.get(field), f"dataset manifest {field}")
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            raise GroundedEvalError(f"dataset manifest {field} does not match {path}")
    return {
        "dataset_manifest_sha256": hashlib.sha256(dataset_manifest_path.read_bytes()).hexdigest(),
        "frozen_eval_sha256": hashlib.sha256(cases_path.read_bytes()).hexdigest(),
        "retrieval_index_sha256": hashlib.sha256(retrieval_index_path.read_bytes()).hexdigest()
        if retrieval_index_path is not None
        else "",
        "source_manifest_sha256": hashlib.sha256(source_manifest_path.read_bytes()).hexdigest()
        if source_manifest_path is not None
        else "",
    }


def _text(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise GroundedEvalError(f"{field} must be a non-empty string")
    return value.strip()


def _resolve_evidence(case: dict[str, Any], catalog: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    evidence = case.get("evidence")
    if not isinstance(evidence, list) or not evidence:
        raise GroundedEvalError("evidence must be a non-empty list")
    source_document_ids = case.get("source_document_ids")
    if not isinstance(source_document_ids, list) or not source_document_ids:
        raise GroundedEvalError("source_document_ids must be a non-empty list")
    declared_documents = {_text(value, "source_document_ids") for value in source_document_ids}

    resolved = []
    for item in evidence:
        if not isinstance(item, dict):
            raise GroundedEvalError("each evidence item must be an object")
        chunk_id = _text(item.get("chunk_id"), "evidence.chunk_id")
        document_id = _text(item.get("document_id"), "evidence.document_id")
        text_sha256 = _text(item.get("text_sha256"), "evidence.text_sha256")
        indexed = catalog.get(chunk_id)
        if indexed is None:
            raise GroundedEvalError(f"evidence chunk is absent from the verified index: {chunk_id}")
        if indexed["document_id"] != document_id or indexed["text_sha256"] != text_sha256:
            raise GroundedEvalError(f"evidence identity/hash does not match verified index: {chunk_id}")
        resolved.append(indexed)

    resolved_documents = {item["document_id"] for item in resolved}
    if resolved_documents != declared_documents:
        raise GroundedEvalError("source_document_ids do not exactly match resolved evidence")
    required_citations = case.get("required_citations")
    if not isinstance(required_citations, list):
        raise GroundedEvalError("required_citations must be a list")
    requested_citations = {_text(value, "required_citations") for value in required_citations}
    available_citations = {item["citation"] for item in resolved}
    if not requested_citations.issubset(available_citations):
        raise GroundedEvalError("required_citations must be present in resolved evidence")
    return resolved


def build_prompt(case: dict[str, Any], catalog: dict[str, dict[str, Any]]) -> str:
    prompt = _text(case.get("prompt"), "prompt")
    rendered = [f"[{item['citation']}]\n{item['text']}" for item in _resolve_evidence(case, catalog)]

    return (
        f"{RESPONSE_POLICY}\n\n"
        f"Question:\n{prompt}\n\nRetrieved evidence:\n" + "\n\n".join(rendered)
    )


def run_case(
    base_url: str, model: str, case: dict[str, Any], catalog: dict[str, dict[str, Any]], timeout: float
) -> dict[str, Any]:
    started = time.perf_counter()
    response = requests.post(
        f"{base_url}/api/generate",
        json={"model": model, "prompt": build_prompt(case, catalog), "stream": False},
        timeout=timeout,
    )
    response.raise_for_status()
    output = response.json().get("response", "")
    result = score_response(case, output)
    result.update({"prompt": case["prompt"], "output": output, "elapsed": time.perf_counter() - started})
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Run citation-required grounded evals against Ollama.")
    parser.add_argument("--model", default="hackidle-nist-coder")
    parser.add_argument("--cases", type=Path, default=DEFAULT_CASES_PATH)
    parser.add_argument(
        "--dataset-manifest", type=Path, default=Path("data/grounded/training/dataset_manifest.json")
    )
    parser.add_argument("--index", type=Path, default=Path("data/index/retrieval_index.jsonl"))
    parser.add_argument("--source-manifest", type=Path, default=Path("data/index/source_manifest.jsonl"))
    parser.add_argument("--extracted-dir", type=Path, default=Path("data/extracted"))
    parser.add_argument("--base-url", default=resolve_base_url())
    parser.add_argument("--timeout", type=float, default=120.0)
    parser.add_argument("--json-output", type=Path)
    args = parser.parse_args()

    if not args.cases.is_file():
        print(f"Cases file not found: {args.cases}", file=sys.stderr)
        return 1
    try:
        cases = load_cases(args.cases)
        contract = validate_frozen_contract(
            args.dataset_manifest, args.cases, args.index, args.source_manifest
        )
        catalog = load_verified_index(args.index, args.source_manifest, extracted_dir=args.extracted_dir)
        for case in cases:
            _resolve_evidence(case, catalog)
    except (GroundedEvalError, RetrievalError) as exc:
        print(f"Eval contract is invalid: {exc}", file=sys.stderr)
        return 2

    results = []
    failures = 0
    for case in cases:
        try:
            result = run_case(args.base_url, args.model, case, catalog, args.timeout)
        except (requests.RequestException, GroundedEvalError) as exc:
            result = {"id": case.get("id", "unknown"), "passed": False, "request_error": str(exc)}
        results.append(result)
        status = "PASS" if result["passed"] else "FAIL"
        print(f"[{status}] {result['id']}")
        if not result["passed"]:
            failures += 1
            if "citation_misses" in result:
                print(f"  missing citations: {', '.join(result['citation_misses']) or 'none'}")
                print(f"  missing claim groups: {result['claim_group_misses'] or 'none'}")
            else:
                print(f"  request error: {result['request_error']}")

    report = {
        "generated_at": datetime.now().astimezone().isoformat(),
        "model": args.model,
        "base_url": args.base_url,
        "cases_file": str(args.cases),
        "dataset_manifest": str(args.dataset_manifest),
        "dataset_manifest_sha256": contract["dataset_manifest_sha256"],
        "frozen_eval_sha256": contract["frozen_eval_sha256"],
        "total_cases": len(cases),
        "passed_cases": len(cases) - failures,
        "failed_cases": failures,
        "automated_contract_only": True,
        "manual_grounding_review_required": True,
        "release_eligible": False,
        "results": results,
    }
    if args.json_output:
        args.json_output.parent.mkdir(parents=True, exist_ok=True)
        args.json_output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
        print(f"JSON report written to {args.json_output}")
    print("Automated contract checks do not establish grounding; manual evidence review is required before release.")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
