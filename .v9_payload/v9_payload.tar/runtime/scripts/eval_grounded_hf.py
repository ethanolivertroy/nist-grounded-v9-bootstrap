#!/usr/bin/env python3
# /// script
# requires-python = ">=3.10"
# dependencies = [
#   "accelerate>=1.2,<2",
#   "huggingface_hub>=0.29,<1",
#   "peft>=0.14,<1",
#   "requests>=2.31,<3",
#   "torch>=2.5,<2.8",
#   "transformers>=4.54,<5",
# ]
# ///
"""Run the frozen grounded-evaluation contract against a Hub PEFT adapter."""

from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
from io import BytesIO
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import time
from typing import Any, Callable

PROJECT_ROOT = Path(os.environ.get("HF_GROUNDED_PROJECT_ROOT", Path(__file__).resolve().parents[1]))
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))



class GroundedHfEvalError(RuntimeError):
    """Raised for model-loading or persistence failures in a Hub adapter evaluation."""


# Direct job execution defers evaluator imports until the source bundle is verified.
GroundedEvalError = GroundedHfEvalError
RetrievalError = GroundedHfEvalError
_DEPENDENCIES_LOADED = False


def _load_evaluator_dependencies() -> None:
    """Import evaluator code only after bootstrap validation in a direct job process."""
    global GroundedEvalError, RetrievalError, _resolve_evidence, build_prompt, load_cases
    global validate_frozen_contract, score_response, RESPONSE_POLICY, load_verified_index, _DEPENDENCIES_LOADED
    if _DEPENDENCIES_LOADED:
        return
    from scripts.eval_grounded_ollama import (
        GroundedEvalError as imported_grounded_error,
        _resolve_evidence as imported_resolve_evidence,
        build_prompt as imported_build_prompt,
        load_cases as imported_load_cases,
        validate_frozen_contract as imported_validate_frozen_contract,
    )
    from src.grounded_eval import score_response as imported_score_response
    from src.grounded_instruction import RESPONSE_POLICY as imported_response_policy
    from src.retrieve_evidence import RetrievalError as imported_retrieval_error, load_verified_index as imported_load_verified_index

    GroundedEvalError = imported_grounded_error
    RetrievalError = imported_retrieval_error
    _resolve_evidence = imported_resolve_evidence
    build_prompt = imported_build_prompt
    load_cases = imported_load_cases
    validate_frozen_contract = imported_validate_frozen_contract
    score_response = imported_score_response
    RESPONSE_POLICY = imported_response_policy
    load_verified_index = imported_load_verified_index
    _DEPENDENCIES_LOADED = True


def evaluation_system_prompt() -> str:
    """Return the shared response policy used by both SFT and frozen generation."""
    return RESPONSE_POLICY


RUNTIME_BUNDLE_RELATIVE_PATHS = (
    "scripts/eval_grounded_hf.py",
    "scripts/eval_grounded_ollama.py",
    "src/grounded_instruction.py",
    "src/grounded_eval.py",
    "src/retrieve_evidence.py",
    "src/build_retrieval_index.py",
)


def runtime_bundle_file_hashes(project_root: Path | None = None) -> dict[str, str]:
    """Hash every source file needed by the isolated evaluator bundle."""
    root = project_root or PROJECT_ROOT
    result = {}
    for relative_path in RUNTIME_BUNDLE_RELATIVE_PATHS:
        path = root / relative_path
        if not path.is_file():
            raise GroundedHfEvalError(f"evaluation runtime file is missing: {path}")
        result[relative_path] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result


def bootstrap_validate_runtime(execution_manifest_path: Path, *, project_root: Path | None = None) -> dict[str, str]:
    """Verify read-only source bytes before importing evaluator dependencies in a job process."""
    if not execution_manifest_path.is_file():
        raise GroundedHfEvalError(f"execution manifest not found: {execution_manifest_path}")
    try:
        execution_manifest = json.loads(execution_manifest_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise GroundedHfEvalError(f"invalid execution manifest: {exc.msg}") from exc
    if not isinstance(execution_manifest, dict):
        raise GroundedHfEvalError("execution manifest must be an object")
    expected = execution_manifest.get("runtime_bundle_files")
    root = project_root or PROJECT_ROOT
    actual = runtime_bundle_file_hashes(root)
    if expected != actual:
        raise GroundedHfEvalError("execution manifest runtime bundle hashes do not match the pre-import runtime")
    if os.environ.get("PYTHONPYCACHEPREFIX"):
        raise GroundedHfEvalError("evaluation runtime forbids PYTHONPYCACHEPREFIX")
    sys.dont_write_bytecode = True
    for relative_path in RUNTIME_BUNDLE_RELATIVE_PATHS:
        source_path = root / relative_path
        if source_path.parent.stat().st_mode & 0o222:
            raise GroundedHfEvalError(f"evaluation runtime source directory must be read-only: {source_path.parent}")
        if source_path.stat().st_mode & 0o222:
            raise GroundedHfEvalError(f"evaluation runtime source must be read-only: {source_path}")
        bytecode_dir = source_path.parent / "__pycache__"
        if bytecode_dir.exists():
            raise GroundedHfEvalError(f"evaluation runtime must not contain bytecode cache: {bytecode_dir}")
    return actual


def snapshot_bound_files(snapshot_root: Path, artifacts: dict[str, Path]) -> dict[str, Path]:
    """Copy each requested artifact once so validation and evaluation use identical bytes."""
    snapshot_root.mkdir(parents=True, exist_ok=False)
    snapshots: dict[str, Path] = {}
    for label, source_path in artifacts.items():
        if not isinstance(label, str) or Path(label).name != label:
            raise GroundedHfEvalError("snapshot artifact labels must be simple filenames")
        if not source_path.is_file():
            raise GroundedHfEvalError(f"snapshot artifact not found: {source_path}")
        try:
            contents = source_path.read_bytes()
        except OSError as exc:
            raise GroundedHfEvalError(f"could not snapshot artifact {source_path}: {exc}") from exc
        snapshot_path = snapshot_root / label
        snapshot_path.write_bytes(contents)
        snapshot_path.chmod(0o400)
        snapshots[label] = snapshot_path
    snapshot_root.chmod(0o500)
    return snapshots


def evaluation_protocol_sha256(paths: tuple[Path, ...] | None = None) -> str:
    """Fingerprint every runtime module that can affect evaluation behavior."""
    files = paths or tuple(PROJECT_ROOT / relative_path for relative_path in RUNTIME_BUNDLE_RELATIVE_PATHS)
    digest = hashlib.sha256()
    for path in files:
        if not path.is_file():
            raise GroundedHfEvalError(f"evaluation protocol file is missing: {path}")
        digest.update(path.name.encode("utf-8"))
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()


def validate_evaluation_target(adapter: str | None, report_repo: str | None) -> tuple[str, str]:
    """Select a target without allowing a base-model report to disappear into an adapter repo."""
    if adapter:
        return "adapter", report_repo or adapter
    if not report_repo:
        raise GroundedHfEvalError("base-model evaluation requires a distinct report repository")
    return "base-model", report_repo


def validate_hub_revision(revision: str | None, label: str) -> str | None:
    """Accept only immutable 40-hex Hugging Face Git commit revisions when supplied."""
    if revision is None:
        return None
    value = revision.strip().lower()
    if not re.fullmatch(r"[0-9a-f]{40}", value):
        raise GroundedHfEvalError(f"{label} revision must be a 40-character lowercase hexadecimal commit SHA")
    return value


def model_revision_kwargs(revision: str | None) -> dict[str, str]:
    """Forward a previously validated immutable revision to Hub model loaders."""
    return {"revision": revision} if revision else {}


def _require_sha256(value: Any, label: str) -> str:
    if not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{64}", value):
        raise GroundedHfEvalError(f"{label} must be a lowercase SHA-256 digest")
    return value


def authorization_manifest_precommit_sha256(path: Path) -> str:
    """Hash the authorization payload while excluding only its reciprocal hash fields.

    An exact two-way file hash would be circular: the authorization binds the complete
    execution-file hash, while the execution must bind the authorization.  This
    precommit hashes every other authorization field (including scope, budget, panel,
    and frozen-artifact contract) and is then embedded in the execution manifest.
    """
    if not path.is_file():
        raise GroundedHfEvalError(f"authorization manifest not found: {path}")
    try:
        authorization = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise GroundedHfEvalError(f"invalid authorization manifest: {exc.msg}") from exc
    if not isinstance(authorization, dict):
        raise GroundedHfEvalError("authorization manifest must be an object")
    payload = json.loads(json.dumps(authorization))
    contract = payload.get("contract")
    if isinstance(contract, dict):
        contract.pop("execution_manifest_sha256", None)
        contract.pop("authorization_precommit_sha256", None)
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def validate_execution_manifest(
    path: Path,
    *,
    base_model: str,
    base_model_revision: str | None,
    adapter: str | None,
    evaluation_target: str,
    report_repo: str,
    dataset_manifest_sha256: str,
    frozen_eval_sha256: str,
    evaluation_protocol_sha256: str,
    runtime_file_hashes: dict[str, str],
    retrieval_index_sha256: str | None = None,
    source_manifest_sha256: str | None = None,
    authorization_precommit_sha256: str | None = None,
    max_new_tokens: int | None = None,
) -> str:
    """Fail closed unless this invocation is one registered revision-pinned base probe."""
    if not path.is_file():
        raise GroundedHfEvalError(f"execution manifest not found: {path}")
    try:
        manifest = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise GroundedHfEvalError(f"invalid execution manifest: {exc.msg}") from exc
    if not isinstance(manifest, dict):
        raise GroundedHfEvalError("execution manifest must be an object")
    if manifest.get("schema_version") != "grounded-base-probe-execution-v1":
        raise GroundedHfEvalError("execution manifest schema is unsupported")
    if manifest.get("mode") != "base-capability-sweep":
        raise GroundedHfEvalError("execution manifest is not a base capability sweep")
    if adapter is not None or evaluation_target != "base-model":
        raise GroundedHfEvalError("execution manifest permits base-model only evaluations")
    if validate_hub_revision(base_model_revision, "base model") is None:
        raise GroundedHfEvalError("execution manifest requires a pinned base model revision")
    if manifest.get("evaluation_protocol_sha256") != evaluation_protocol_sha256:
        raise GroundedHfEvalError("execution manifest protocol hash does not match the runtime")
    declared_runtime = manifest.get("runtime_bundle_files")
    if declared_runtime != runtime_file_hashes:
        raise GroundedHfEvalError("execution manifest runtime bundle hashes do not match the runtime")
    contract = manifest.get("contract")
    if not isinstance(contract, dict):
        raise GroundedHfEvalError("execution manifest contract must be an object")
    if contract.get("dataset_manifest_sha256") != dataset_manifest_sha256:
        raise GroundedHfEvalError("execution manifest dataset manifest does not match the runtime")
    if contract.get("frozen_eval_sha256") != frozen_eval_sha256:
        raise GroundedHfEvalError("execution manifest frozen evaluation does not match the runtime")
    declared_retrieval_index_sha256 = _require_sha256(
        contract.get("retrieval_index_sha256"), "execution manifest retrieval index"
    )
    if retrieval_index_sha256 is None or declared_retrieval_index_sha256 != retrieval_index_sha256:
        raise GroundedHfEvalError("execution manifest retrieval index does not match the runtime")
    declared_source_manifest_sha256 = _require_sha256(
        contract.get("source_manifest_sha256"), "execution manifest source manifest"
    )
    if source_manifest_sha256 is None or declared_source_manifest_sha256 != source_manifest_sha256:
        raise GroundedHfEvalError("execution manifest source manifest does not match the runtime")
    declared_authorization_precommit_sha256 = _require_sha256(
        manifest.get("authorization_precommit_sha256"), "execution manifest authorization precommit"
    )
    if (
        authorization_precommit_sha256 is None
        or declared_authorization_precommit_sha256 != authorization_precommit_sha256
    ):
        raise GroundedHfEvalError("execution manifest authorization precommit does not match the runtime")
    generation = manifest.get("generation")
    if (
        not isinstance(generation, dict)
        or set(generation) != {"max_new_tokens", "do_sample"}
        or not isinstance(generation.get("max_new_tokens"), int)
        or generation["max_new_tokens"] != 256
        or generation.get("do_sample") is not False
        or max_new_tokens != 256
        or generation["max_new_tokens"] != max_new_tokens
    ):
        raise GroundedHfEvalError("execution manifest generation contract must be exactly max_new_tokens=256 and do_sample=false")
    matrix = manifest.get("probe_matrix")
    if not isinstance(matrix, list) or not matrix:
        raise GroundedHfEvalError("execution manifest probe matrix must be a non-empty list")
    pairs = set()
    for row in matrix:
        if not isinstance(row, dict):
            raise GroundedHfEvalError("execution manifest probe rows must be objects")
        model_id = row.get("model_id")
        if not isinstance(model_id, str) or not model_id.strip():
            raise GroundedHfEvalError("execution manifest probe model ID must be a non-empty string")
        revision = validate_hub_revision(row.get("revision"), "probe model")
        _require_sha256(row.get("candidate_snapshot_sha256"), "candidate snapshot SHA-256")
        registered_report_repo = row.get("report_repo")
        if not isinstance(registered_report_repo, str) or not registered_report_repo.strip():
            raise GroundedHfEvalError("execution manifest probe report repository must be a non-empty string")
        pair = (model_id, revision, registered_report_repo)
        if pair in pairs:
            raise GroundedHfEvalError("execution manifest contains a duplicate probe model/revision/report repository")
        pairs.add(pair)
    if (base_model, base_model_revision, report_repo) not in pairs:
        raise GroundedHfEvalError("requested base model/revision/report repository is not registered in the execution manifest")
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_authorization_manifest(
    path: Path, *, execution_manifest_sha256: str, execution_manifest: dict[str, Any]
) -> str:
    """Bind an execution manifest to the explicit base-probes-only paid authorization."""
    if not path.is_file():
        raise GroundedHfEvalError(f"authorization manifest not found: {path}")
    try:
        authorization = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise GroundedHfEvalError(f"invalid authorization manifest: {exc.msg}") from exc
    if not isinstance(authorization, dict):
        raise GroundedHfEvalError("authorization manifest must be an object")
    if authorization.get("schema_version") != "grounded-base-probe-authorization-v1":
        raise GroundedHfEvalError("authorization manifest schema is unsupported")
    if authorization.get("scope") != "base-probes-only":
        raise GroundedHfEvalError("authorization manifest does not authorize base probes only")
    contract = authorization.get("contract")
    if not isinstance(contract, dict) or contract.get("execution_manifest_sha256") != execution_manifest_sha256:
        raise GroundedHfEvalError("authorization manifest execution manifest hash does not match the runtime")
    actual_authorization_precommit_sha256 = authorization_manifest_precommit_sha256(path)
    declared_authorization_precommit_sha256 = _require_sha256(
        contract.get("authorization_precommit_sha256"), "authorization manifest authorization precommit"
    )
    if declared_authorization_precommit_sha256 != actual_authorization_precommit_sha256:
        raise GroundedHfEvalError("authorization manifest authorization precommit does not match its payload")
    if not isinstance(execution_manifest, dict) or execution_manifest.get(
        "authorization_precommit_sha256"
    ) != actual_authorization_precommit_sha256:
        raise GroundedHfEvalError("authorization manifest authorization precommit does not match the execution manifest")
    if contract.get("generation") != execution_manifest.get("generation"):
        raise GroundedHfEvalError("authorization manifest generation contract does not match the execution manifest")
    panel = authorization.get("panel")
    matrix = execution_manifest.get("probe_matrix") if isinstance(execution_manifest, dict) else None
    if not isinstance(panel, list) or not isinstance(matrix, list):
        raise GroundedHfEvalError("authorization manifest panel does not match the execution manifest")
    binding_keys = ("model_id", "revision", "candidate_snapshot_sha256", "report_repo")
    panel_bindings = [{key: row.get(key) for key in binding_keys} if isinstance(row, dict) else None for row in panel]
    if panel_bindings != matrix:
        raise GroundedHfEvalError("authorization manifest panel does not match the execution manifest")
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_case(
    case: dict[str, Any], catalog: dict[str, dict[str, Any]], generate: Callable[[str], str]
) -> dict[str, Any]:
    """Generate only after evidence validation and score the completion contract."""
    started = time.perf_counter()
    output = generate(build_prompt(case, catalog))
    result = score_response(case, output)
    result.update({"prompt": case["prompt"], "output": output, "elapsed": time.perf_counter() - started})
    return result


def make_generator(
    base_model: str,
    adapter: str | None,
    max_new_tokens: int,
    *,
    base_model_revision: str | None = None,
    adapter_revision: str | None = None,
) -> Callable[[str], str]:
    try:
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
    except ImportError as exc:
        raise GroundedHfEvalError("CUDA evaluation dependencies are unavailable") from exc
    if not torch.cuda.is_available():
        raise GroundedHfEvalError("a CUDA GPU is required to evaluate this 7B adapter")
    if max_new_tokens < 1:
        raise GroundedHfEvalError("max_new_tokens must be positive")
    base_model_revision = validate_hub_revision(base_model_revision, "base model")
    adapter_revision = validate_hub_revision(adapter_revision, "adapter")
    if adapter is None and adapter_revision is not None:
        raise GroundedHfEvalError("adapter revision requires an adapter")

    tokenizer = AutoTokenizer.from_pretrained(
        base_model, use_fast=True, **model_revision_kwargs(base_model_revision)
    )
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        base_model,
        torch_dtype=torch.bfloat16,
        device_map="auto",
        use_cache=True,
        **model_revision_kwargs(base_model_revision),
    )
    if adapter:
        try:
            from peft import PeftModel
        except ImportError as exc:
            raise GroundedHfEvalError("peft is required to evaluate an adapter") from exc
        model = PeftModel.from_pretrained(model, adapter, **model_revision_kwargs(adapter_revision))
    model.eval()

    def generate(prompt: str) -> str:
        messages = [
            {
                "role": "system",
                "content": evaluation_system_prompt(),
            },
            {"role": "user", "content": prompt},
        ]
        inputs = tokenizer.apply_chat_template(
            messages, tokenize=True, add_generation_prompt=True, return_tensors="pt", return_dict=True
        )
        inputs = {key: value.to(model.device) for key, value in inputs.items()}
        with torch.inference_mode():
            generated = model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                do_sample=False,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
            )
        completion = generated[0][inputs["input_ids"].shape[1] :]
        return tokenizer.decode(completion, skip_special_tokens=True).strip()

    return generate


def upload_report(report_repo: str, report_path: Path) -> None:
    try:
        from huggingface_hub import HfApi
    except ImportError as exc:
        raise GroundedHfEvalError("huggingface_hub is required to persist the evaluation report") from exc
    try:
        HfApi().upload_file(
            path_or_fileobj=BytesIO(report_path.read_bytes()),
            path_in_repo="frozen_eval_report.json",
            repo_id=report_repo,
            repo_type="model",
            commit_message="Add frozen grounded evaluation report",
        )
    except Exception as exc:
        raise GroundedHfEvalError(f"failed to upload frozen evaluation report: {exc}") from exc


def main() -> int:
    parser = argparse.ArgumentParser(description="Run frozen grounded evals against a Hugging Face PEFT adapter.")
    parser.add_argument("--base-model", default="Qwen/Qwen2.5-Coder-7B-Instruct")
    parser.add_argument(
        "--base-revision", help="Optional immutable 40-hex Hub commit SHA for the selected base model"
    )
    parser.add_argument(
        "--adapter", help="Private Hub model repository holding the PEFT adapter; omit for a base-model baseline"
    )
    parser.add_argument(
        "--adapter-revision", help="Optional immutable 40-hex Hub commit SHA for the adapter repository"
    )
    parser.add_argument(
        "--execution-manifest",
        type=Path,
        required=True,
        help="Required fail-closed base-probe manifest: permits only its registered revision-pinned base matrix",
    )
    parser.add_argument(
        "--authorization-manifest",
        type=Path,
        required=True,
        help="Required base-probes-only preregistration that must bind this exact execution manifest",
    )
    parser.add_argument(
        "--report-repo",
        help="Private Hub model repository to receive frozen_eval_report.json; required for base-model baselines",
    )
    parser.add_argument("--cases", type=Path, default=Path("data/grounded/frozen_eval.jsonl"))
    parser.add_argument(
        "--dataset-manifest", type=Path, default=Path("data/grounded/training/dataset_manifest.json")
    )
    parser.add_argument("--index", type=Path, default=Path("data/index/retrieval_index.jsonl"))
    parser.add_argument("--source-manifest", type=Path, default=Path("data/index/source_manifest.jsonl"))
    parser.add_argument("--extracted-dir", type=Path, default=Path("data/extracted"))
    parser.add_argument("--max-new-tokens", type=int, default=256)
    parser.add_argument("--json-output", type=Path, default=Path("/tmp/frozen_eval_report.json"))
    args = parser.parse_args()

    try:
        bootstrap_runtime_files = bootstrap_validate_runtime(args.execution_manifest)
        _load_evaluator_dependencies()
        evaluation_target, report_repo = validate_evaluation_target(args.adapter, args.report_repo)
        base_model_revision = validate_hub_revision(args.base_revision, "base model")
        adapter_revision = validate_hub_revision(args.adapter_revision, "adapter")
        if args.adapter is None and adapter_revision is not None:
            raise GroundedHfEvalError("adapter revision requires an adapter")
        snapshot_workspace = tempfile.TemporaryDirectory(prefix="grounded-eval-bound-")
        snapshots = snapshot_bound_files(
            Path(snapshot_workspace.name) / "inputs",
            {
                "cases.jsonl": args.cases,
                "dataset_manifest.json": args.dataset_manifest,
                "retrieval_index.jsonl": args.index,
                "source_manifest.jsonl": args.source_manifest,
                "execution_manifest.json": args.execution_manifest,
                "authorization_manifest.json": args.authorization_manifest,
            },
        )
        cases = load_cases(snapshots["cases.jsonl"])
        contract = validate_frozen_contract(
            snapshots["dataset_manifest.json"],
            snapshots["cases.jsonl"],
            snapshots["retrieval_index.jsonl"],
            snapshots["source_manifest.jsonl"],
        )
        catalog = load_verified_index(
            snapshots["retrieval_index.jsonl"],
            snapshots["source_manifest.jsonl"],
            extracted_dir=args.extracted_dir,
        )
        for case in cases:
            _resolve_evidence(case, catalog)
        protocol_sha256 = evaluation_protocol_sha256()
        runtime_files = bootstrap_runtime_files
        authorization_precommit_sha256 = authorization_manifest_precommit_sha256(
            snapshots["authorization_manifest.json"]
        )
        execution_manifest_sha256 = validate_execution_manifest(
            snapshots["execution_manifest.json"],
            base_model=args.base_model,
            base_model_revision=base_model_revision,
            adapter=args.adapter,
            evaluation_target=evaluation_target,
            report_repo=report_repo,
            dataset_manifest_sha256=contract["dataset_manifest_sha256"],
            frozen_eval_sha256=contract["frozen_eval_sha256"],
            retrieval_index_sha256=contract["retrieval_index_sha256"],
            source_manifest_sha256=contract["source_manifest_sha256"],
            authorization_precommit_sha256=authorization_precommit_sha256,
            max_new_tokens=args.max_new_tokens,
            evaluation_protocol_sha256=protocol_sha256,
            runtime_file_hashes=runtime_files,
        )
        execution_manifest = json.loads(snapshots["execution_manifest.json"].read_text(encoding="utf-8"))
        authorization_manifest_sha256 = validate_authorization_manifest(
            snapshots["authorization_manifest.json"],
            execution_manifest_sha256=execution_manifest_sha256,
            execution_manifest=execution_manifest,
        )
        generate = make_generator(
            args.base_model,
            args.adapter,
            args.max_new_tokens,
            base_model_revision=base_model_revision,
            adapter_revision=adapter_revision,
        )
    except (GroundedEvalError, GroundedHfEvalError, RetrievalError) as exc:
        print(f"Eval contract or runtime is invalid: {exc}", file=sys.stderr)
        return 2

    results = []
    failures = 0
    for case in cases:
        try:
            result = run_case(case, catalog, generate)
        except (GroundedEvalError, GroundedHfEvalError, RuntimeError) as exc:
            result = {"id": case.get("id", "unknown"), "passed": False, "request_error": str(exc)}
        results.append(result)
        status = "PASS" if result["passed"] else "FAIL"
        print(f"[{status}] {result['id']}")
        if not result["passed"]:
            failures += 1

    report = {
        "generated_at": datetime.now().astimezone().isoformat(),
        "base_model": args.base_model,
        "base_model_revision": base_model_revision,
        "adapter": args.adapter,
        "adapter_revision": adapter_revision,
        "evaluation_target": evaluation_target,
        "report_repository": report_repo,
        "cases_file": str(args.cases),
        "dataset_manifest": str(args.dataset_manifest),
        "dataset_manifest_sha256": contract["dataset_manifest_sha256"],
        "frozen_eval_sha256": contract["frozen_eval_sha256"],
        "retrieval_index_sha256": contract["retrieval_index_sha256"],
        "source_manifest_sha256": contract["source_manifest_sha256"],
        "authorization_precommit_sha256": authorization_precommit_sha256,
        "generation": {"max_new_tokens": args.max_new_tokens, "do_sample": False},
        "evaluation_protocol_sha256": protocol_sha256,
        "runtime_bundle_files": runtime_files,
        "execution_manifest": str(args.execution_manifest),
        "execution_manifest_sha256": execution_manifest_sha256,
        "authorization_manifest": str(args.authorization_manifest),
        "authorization_manifest_sha256": authorization_manifest_sha256,
        "total_cases": len(cases),
        "passed_cases": len(cases) - failures,
        "failed_cases": failures,
        "automated_contract_only": True,
        "manual_grounding_review_required": True,
        "release_eligible": False,
        "results": results,
    }
    args.json_output.parent.mkdir(parents=True, exist_ok=True)
    args.json_output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    try:
        upload_report(report_repo, args.json_output)
    except GroundedHfEvalError as exc:
        print(f"Could not persist frozen evaluation report: {exc}", file=sys.stderr)
        return 2
    print(f"Frozen evaluation report uploaded to {report_repo}:frozen_eval_report.json")
    print("Automated contract checks do not establish grounding; manual evidence review is required before release.")
    return 1 if failures else 0


if __name__ != "__main__":
    _load_evaluator_dependencies()


if __name__ == "__main__":
    raise SystemExit(main())
