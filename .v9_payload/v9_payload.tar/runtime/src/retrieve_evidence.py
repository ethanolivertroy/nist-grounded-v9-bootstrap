#!/usr/bin/env python3
"""Retrieve verified local source passages with transparent lexical scores."""

from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import math
import re
import sys
import tempfile
from pathlib import Path
from typing import Any

try:
    from .build_retrieval_index import RetrievalIndexError, build_retrieval_index
except ImportError:  # Supports `python src/retrieve_evidence.py`.
    from build_retrieval_index import RetrievalIndexError, build_retrieval_index


class RetrievalError(ValueError):
    """Raised when a local retrieval index or its source authority is invalid."""


TOKEN_PATTERN = re.compile(r"[a-z0-9][a-z0-9-]*", re.IGNORECASE)


def _tokens(text: str) -> list[str]:
    return TOKEN_PATTERN.findall(text.lower())


def _read_jsonl(path: Path, label: str) -> list[dict[str, Any]]:
    if not path.is_file():
        raise RetrievalError(f"{label} does not exist: {path}")
    rows = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError as exc:
            raise RetrievalError(f"invalid JSON in {path.name} line {line_number}: {exc.msg}") from exc
        if not isinstance(row, dict):
            raise RetrievalError(f"{label} line {line_number} must be an object")
        rows.append(row)
    return rows


def _text(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise RetrievalError(f"{field} must be a non-empty string")
    return value.strip()


def _manifest_by_document(source_manifest_path: Path) -> dict[str, dict[str, Any]]:
    documents: dict[str, dict[str, Any]] = {}
    for row in _read_jsonl(source_manifest_path, "source manifest"):
        document_id = _text(row.get("document_id"), "source manifest document_id")
        official_url = _text(row.get("official_url"), "source manifest official_url")
        if not official_url.startswith(("https://", "http://")):
            raise RetrievalError("source manifest official_url must be an HTTP(S) URL")
        _text(row.get("source_file"), "source manifest source_file")
        if document_id in documents:
            raise RetrievalError(f"duplicate source manifest document_id: {document_id}")
        documents[document_id] = row
    if not documents:
        raise RetrievalError("source manifest contains no documents")
    return documents


def _assert_matches_verified_reconstruction(
    index_path: Path,
    source_manifest_path: Path,
    extracted_dir: Path,
    max_chunk_chars: int,
    catalog: dict[str, dict[str, Any]],
) -> None:
    """Reject an index unless it exactly matches a fresh source-pinned reconstruction."""
    try:
        with tempfile.TemporaryDirectory(prefix="nist-index-verify-") as temporary_dir:
            expected_path = Path(temporary_dir) / "expected_index.jsonl"
            build_retrieval_index(
                extracted_dir, source_manifest_path, expected_path, max_chunk_chars=max_chunk_chars
            )
            expected_rows = _read_jsonl(expected_path, "reconstructed retrieval index")
    except RetrievalIndexError as exc:
        raise RetrievalError(f"verified reconstruction failed: {exc}") from exc

    expected_by_chunk = {row.get("chunk_id"): row for row in expected_rows}
    if len(expected_by_chunk) != len(expected_rows) or None in expected_by_chunk:
        raise RetrievalError("verified reconstruction has invalid or duplicate chunk IDs")
    if catalog != expected_by_chunk:
        raise RetrievalError("retrieval index does not match the verified reconstruction")


def load_verified_index(
    index_path: Path,
    source_manifest_path: Path,
    extracted_dir: Path | None = None,
    max_chunk_chars: int = 1800,
) -> dict[str, dict[str, Any]]:
    """Load an index only when every chunk matches a manifest document and its hash."""
    if not source_manifest_path.is_file():
        raise RetrievalError(f"source manifest does not exist: {source_manifest_path}")
    source_manifest_sha256 = hashlib.sha256(source_manifest_path.read_bytes()).hexdigest()
    documents = _manifest_by_document(source_manifest_path)
    catalog: dict[str, dict[str, Any]] = {}
    for row in _read_jsonl(index_path, "retrieval index"):
        chunk_id = _text(row.get("chunk_id"), "index chunk_id")
        document_id = _text(row.get("document_id"), "index document_id")
        citation = _text(row.get("citation"), "index citation")
        text = _text(row.get("text"), "index text")
        text_sha256 = _text(row.get("text_sha256"), "index text_sha256")
        official_url = _text(row.get("official_url"), "index official_url")
        row_source_manifest_sha256 = _text(
            row.get("source_manifest_sha256"), "index source_manifest_sha256"
        )
        if row_source_manifest_sha256 != source_manifest_sha256:
            raise RetrievalError("index source_manifest_sha256 does not match current source manifest")
        if chunk_id in catalog:
            raise RetrievalError(f"duplicate retrieval index chunk_id: {chunk_id}")
        if document_id not in documents:
            raise RetrievalError(f"index document_id is absent from source manifest: {document_id}")
        manifest = documents[document_id]
        if official_url != manifest["official_url"]:
            raise RetrievalError(f"index official_url does not match source manifest for {document_id}")
        if hashlib.sha256(text.encode("utf-8")).hexdigest() != text_sha256:
            raise RetrievalError(f"index text_sha256 does not match chunk {chunk_id}")
        catalog[chunk_id] = {
            **row,
            "chunk_id": chunk_id,
            "document_id": document_id,
            "citation": citation,
            "text": text,
            "text_sha256": text_sha256,
            "official_url": official_url,
        }
    if not catalog:
        raise RetrievalError("retrieval index contains no chunks")
    if extracted_dir is not None:
        _assert_matches_verified_reconstruction(
            index_path, source_manifest_path, extracted_dir, max_chunk_chars, catalog
        )
    return catalog


def search_index(
    index_path: Path,
    source_manifest_path: Path,
    query: str,
    top_k: int = 5,
    extracted_dir: Path | None = None,
    max_chunk_chars: int = 1800,
) -> list[dict[str, Any]]:
    """Return the highest-overlap verified passages, preserving source citations."""
    if not isinstance(query, str) or not query.strip():
        raise RetrievalError("query must be a non-empty string")
    if not isinstance(top_k, int) or top_k < 1:
        raise RetrievalError("top_k must be a positive integer")

    query_counts = Counter(_tokens(query))
    if not query_counts:
        raise RetrievalError("query must contain searchable letters or digits")

    scored = []
    for row in load_verified_index(
        index_path, source_manifest_path, extracted_dir=extracted_dir, max_chunk_chars=max_chunk_chars
    ).values():
        haystack_counts = Counter(_tokens(row["text"]))
        overlap = sum(min(query_count, haystack_counts[token]) for token, query_count in query_counts.items())
        if not overlap:
            continue
        normalized_score = overlap / math.sqrt(sum(haystack_counts.values()))
        scored.append({**row, "score": round(normalized_score, 6)})

    return sorted(scored, key=lambda row: (-row["score"], row["chunk_id"]))[:top_k]


def main() -> int:
    parser = argparse.ArgumentParser(description="Retrieve cited passages from a verified local NIST index.")
    parser.add_argument("query", help="Natural-language question or search terms")
    parser.add_argument("--index", type=Path, default=Path("data/index/retrieval_index.jsonl"))
    parser.add_argument("--source-manifest", type=Path, default=Path("data/index/source_manifest.jsonl"))
    parser.add_argument("--extracted-dir", type=Path, default=Path("data/extracted"))
    parser.add_argument("--max-chunk-chars", type=int, default=1800)
    parser.add_argument("--top-k", type=int, default=5)
    args = parser.parse_args()
    try:
        matches = search_index(
            args.index,
            args.source_manifest,
            args.query,
            args.top_k,
            extracted_dir=args.extracted_dir,
            max_chunk_chars=args.max_chunk_chars,
        )
    except RetrievalError as exc:
        print(f"retrieval failed: {exc}", file=sys.stderr)
        return 2
    print(json.dumps({"query": args.query, "matches": matches}, indent=2, ensure_ascii=False))
    return 0 if matches else 1


if __name__ == "__main__":
    raise SystemExit(main())
