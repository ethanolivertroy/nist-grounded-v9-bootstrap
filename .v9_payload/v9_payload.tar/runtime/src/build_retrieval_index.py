#!/usr/bin/env python3
"""Build a local, hash-pinned lexical retrieval index from extracted publications."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any


class RetrievalIndexError(ValueError):
    """Raised when source or extraction records cannot support cited retrieval."""


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError as exc:
            raise RetrievalIndexError(f"invalid JSONL in {path.name} line {line_number}: {exc.msg}") from exc
        if not isinstance(row, dict):
            raise RetrievalIndexError(f"invalid JSONL object in {path.name} line {line_number}")
        rows.append(row)
    return rows


def _split_text(text: str, max_chunk_chars: int) -> list[str]:
    if not isinstance(text, str) or not text.strip():
        return []
    paragraphs = [part.strip() for part in re.split(r"\n\s*\n", text) if part.strip()]
    chunks: list[str] = []
    current = ""
    for paragraph in paragraphs:
        if len(paragraph) > max_chunk_chars:
            sentences = re.split(r"(?<=[.!?])\s+", paragraph)
        else:
            sentences = [paragraph]
        for sentence in sentences:
            if current and len(current) + len(sentence) + 1 > max_chunk_chars:
                chunks.append(current)
                current = ""
            current = f"{current} {sentence}".strip()
    if current:
        chunks.append(current)
    return chunks


def _fallback_sections(markdown: str) -> list[tuple[str, str]]:
    heading = "Document text"
    text_lines: list[str] = []
    sections: list[tuple[str, str]] = []
    for line in markdown.splitlines():
        if line.startswith("#"):
            if text_lines:
                sections.append((heading, "\n".join(text_lines)))
            heading = line.lstrip("#").strip() or "Document text"
            text_lines = []
        else:
            text_lines.append(line)
    if text_lines:
        sections.append((heading, "\n".join(text_lines)))
    return sections


def _section_texts(document: dict[str, Any]) -> list[tuple[str, str]]:
    values = []
    for section in document.get("sections") or []:
        if not isinstance(section, dict):
            continue
        heading = section.get("heading")
        text = section.get("text")
        if isinstance(heading, str) and heading.strip() and isinstance(text, str) and text.strip():
            values.append((heading.strip(), text.strip()))
    if values:
        return values
    markdown = document.get("markdown")
    return _fallback_sections(markdown) if isinstance(markdown, str) else []


def _citation(manifest: dict[str, Any], heading: str) -> str:
    publication = manifest.get("publication")
    if not isinstance(publication, str) or not publication.strip():
        raise RetrievalIndexError("source manifest entry lacks a canonical publication")
    revision = manifest.get("revision") or ""
    if not isinstance(revision, str):
        raise RetrievalIndexError("source manifest revision must be a string or null")
    locator = heading if heading.startswith("§") else f"§ {heading}"
    return " ".join(part for part in (publication.strip(), revision.strip(), locator) if part)


def build_retrieval_index(
    extracted_dir: Path, source_manifest_path: Path, output_path: Path, max_chunk_chars: int = 1800
) -> dict[str, Any]:
    """Create a citable chunk index from extracted JSON and a source manifest."""
    if max_chunk_chars < 100:
        raise RetrievalIndexError("max_chunk_chars must be at least 100")
    if not extracted_dir.is_dir():
        raise RetrievalIndexError(f"extracted directory does not exist: {extracted_dir}")
    if not source_manifest_path.is_file():
        raise RetrievalIndexError(f"source manifest does not exist: {source_manifest_path}")

    manifest_bytes = source_manifest_path.read_bytes()
    source_manifest_sha256 = hashlib.sha256(manifest_bytes).hexdigest()
    manifest_by_source = {}
    manifest_document_ids = set()
    for row in _read_jsonl(source_manifest_path):
        source_file = row.get("source_file")
        document_id = row.get("document_id")
        required = ("publication", "official_url", "markdown_sha256", "extracted_json_sha256")
        if not isinstance(source_file, str) or not source_file or not isinstance(document_id, str) or not document_id:
            raise RetrievalIndexError("source manifest entries require source_file and document_id")
        if any(not isinstance(row.get(field), str) or not row[field] for field in required):
            raise RetrievalIndexError("source manifest entries require publication, official_url, markdown_sha256, and extracted_json_sha256")
        if not row["official_url"].startswith(("https://", "http://")):
            raise RetrievalIndexError("source manifest official_url must be an HTTP(S) URL")
        if source_file in manifest_by_source:
            raise RetrievalIndexError(f"duplicate source manifest entry for {source_file}")
        if document_id in manifest_document_ids:
            raise RetrievalIndexError(f"duplicate source manifest document_id: {document_id}")
        manifest_by_source[source_file] = row
        manifest_document_ids.add(document_id)

    index_rows = []
    index_by_chunk_id: dict[str, dict[str, Any]] = {}
    for path in sorted(extracted_dir.glob("*.json")):
        if path.name.startswith("extraction_"):
            continue
        try:
            extracted_bytes = path.read_bytes()
            document = json.loads(extracted_bytes)
        except json.JSONDecodeError as exc:
            raise RetrievalIndexError(f"invalid extracted document {path.name}: {exc.msg}") from exc
        if not isinstance(document, dict):
            raise RetrievalIndexError(f"extracted document {path.name} must be an object")
        source_file = document.get("source_file")
        if not isinstance(source_file, str) or source_file not in manifest_by_source:
            raise RetrievalIndexError(f"no source-manifest entry for extracted document {path.name}")
        source = manifest_by_source[source_file]
        if hashlib.sha256(extracted_bytes).hexdigest() != source["extracted_json_sha256"]:
            raise RetrievalIndexError(f"extracted_json_sha256 does not match source manifest for {source_file}")
        markdown = document.get("markdown")
        if not isinstance(markdown, str):
            raise RetrievalIndexError(f"extracted document {path.name} is missing markdown")
        if hashlib.sha256(markdown.encode("utf-8")).hexdigest() != source["markdown_sha256"]:
            raise RetrievalIndexError(f"markdown_sha256 does not match source manifest for {source_file}")
        index_size_before_document = len(index_rows)
        for heading, text in _section_texts(document):
            for chunk_number, text_chunk in enumerate(_split_text(text, max_chunk_chars), start=1):
                section_locator = heading if heading.startswith("§") else f"§ {heading}"
                locator = f"{section_locator} ¶ {chunk_number}"
                identity = "\0".join((source["document_id"], locator, text_chunk))
                row = {
                    "chunk_id": "chunk-" + hashlib.sha256(identity.encode("utf-8")).hexdigest()[:20],
                    "document_id": source["document_id"],
                    "source_file": source_file,
                    "citation": _citation(source, locator),
                    "official_url": source["official_url"],
                    "source_manifest_sha256": source_manifest_sha256,
                    "locator": locator,
                    "text": text_chunk,
                    "text_sha256": hashlib.sha256(text_chunk.encode("utf-8")).hexdigest(),
                }
                existing = index_by_chunk_id.get(row["chunk_id"])
                if existing is not None:
                    if existing != row:
                        raise RetrievalIndexError(
                            f"non-identical retrieval chunk_id collision: {row['chunk_id']}"
                        )
                    continue
                index_by_chunk_id[row["chunk_id"]] = row
                index_rows.append(row)
        if len(index_rows) == index_size_before_document:
            raise RetrievalIndexError(f"extracted source {source_file} generated no citable chunks")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        "".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in index_rows),
        encoding="utf-8",
    )
    return {
        "schema_version": "retrieval-index-v2",
        "chunk_count": len(index_rows),
        "source_manifest_sha256": source_manifest_sha256,
        "index_sha256": hashlib.sha256(output_path.read_bytes()).hexdigest(),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Build a local citable retrieval index.")
    parser.add_argument("--input", type=Path, default=Path("data/extracted"))
    parser.add_argument("--source-manifest", type=Path, default=Path("data/index/source_manifest.jsonl"))
    parser.add_argument("--output", type=Path, default=Path("data/index/retrieval_index.jsonl"))
    parser.add_argument("--max-chunk-chars", type=int, default=1800)
    args = parser.parse_args()
    try:
        summary = build_retrieval_index(
            args.input, args.source_manifest, args.output, args.max_chunk_chars
        )
    except RetrievalIndexError as exc:
        print(f"retrieval-index build failed: {exc}", file=sys.stderr)
        return 2
    print(
        f"Wrote {summary['chunk_count']} retrieval chunks to {args.output} "
        f"(sha256={summary['index_sha256']})"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
