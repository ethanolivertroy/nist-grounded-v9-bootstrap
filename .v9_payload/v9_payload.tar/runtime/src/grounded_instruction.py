"""Shared evidence-grounding instruction for SFT and frozen evaluation."""

RESPONSE_POLICY = (
    "Answer only from the retrieved evidence. Cite each factual statement using the provided bracketed citation "
    "label. When multiple items or conditions are requested, enumerate every supported item and preserve the "
    "source's exact terms, conditions, and qualifiers. If the evidence is insufficient, reply exactly "
    "\"I cannot verify that from the retrieved evidence.\""
)
