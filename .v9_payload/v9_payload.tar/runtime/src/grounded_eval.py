"""Deterministic citation-and-claim scoring for frozen grounded eval cases."""

from __future__ import annotations

from typing import Any
import re


class GroundedEvalError(ValueError):
    """Raised when a frozen eval case lacks an objective scoring contract."""


def _text(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise GroundedEvalError(f"{field} must be a non-empty string")
    return value.strip()


def _phrase_groups(value: Any, allow_empty: bool = False) -> list[list[str]]:
    if not isinstance(value, list) or (not value and not allow_empty):
        raise GroundedEvalError("claim_groups must be a non-empty list")
    groups = []
    for group in value:
        if not isinstance(group, list) or not group:
            raise GroundedEvalError("each claim group must be a non-empty list")
        groups.append([_text(phrase, "claim phrase") for phrase in group])
    return groups


CLEAN_ABSTENTION = re.compile(
    r"^\s*(?:i\s+)?(?:cannot|can't)\s+verify(?:\s+that)?\s+from\s+(?:the\s+)?retrieved\s+evidence\.?\s*$",
    re.IGNORECASE,
)


def _clean_abstention(response: str) -> bool:
    return bool(CLEAN_ABSTENTION.fullmatch(response))


def score_response(case: dict[str, Any], response: str) -> dict[str, Any]:
    """Score a model answer against explicit citation and claim requirements."""
    if not isinstance(case, dict):
        raise GroundedEvalError("case must be an object")
    case_id = _text(case.get("id"), "id")
    _text(case.get("prompt"), "prompt")
    source_document_ids = case.get("source_document_ids")
    if not isinstance(source_document_ids, list) or not source_document_ids:
        raise GroundedEvalError("source_document_ids must be a non-empty list")
    [_text(value, "source_document_id") for value in source_document_ids]
    raw_response = _text(response, "response")
    normalized_response = raw_response.lower()

    abstention_required = bool(case.get("abstention_required", False))
    citations = case.get("required_citations")
    if not isinstance(citations, list) or (not citations and not abstention_required):
        raise GroundedEvalError(
            "required_citations must be a non-empty list unless abstention_required is true"
        )
    citation_labels = [_text(citation, "required citation") for citation in citations]
    citation_matches = [
        citation
        for citation in citation_labels
        if f"[{citation.lower()}]" in normalized_response
    ]
    citation_misses = [citation for citation in citation_labels if citation not in citation_matches]

    groups = _phrase_groups(case.get("claim_groups"), allow_empty=abstention_required)
    minimum = case.get("minimum_claim_groups", len(groups))
    if not isinstance(minimum, int) or not 0 <= minimum <= len(groups):
        raise GroundedEvalError("minimum_claim_groups must be an integer within claim_groups")

    claim_group_matches = []
    claim_group_misses = []
    for group in groups:
        matched = next((phrase for phrase in group if phrase.lower() in normalized_response), None)
        if matched:
            claim_group_matches.append(matched)
        else:
            claim_group_misses.append(group)

    abstention_clean = not abstention_required or _clean_abstention(raw_response)

    passed = (
        not citation_misses
        and len(claim_group_matches) >= minimum
        and abstention_clean
    )
    return {
        "id": case_id,
        "passed": passed,
        "citation_matches": citation_matches,
        "citation_misses": citation_misses,
        "claim_group_matches": claim_group_matches,
        "claim_group_misses": claim_group_misses,
        "minimum_claim_groups": minimum,
        "abstention_required": abstention_required,
        "abstention_clean": abstention_clean,
        "manual_grounding_review_required": True,
        "release_eligible": False,
    }
